module.exports = {
	'url' : 'mongodb://localhost/knoldus' 
};
